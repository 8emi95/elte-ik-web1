function myFunction()
{
	document.getElementsByClassName("menu")[0].classList.toggle("kibont");
}